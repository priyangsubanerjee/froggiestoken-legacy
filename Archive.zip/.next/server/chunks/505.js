"use strict";
exports.id = 505;
exports.ids = [505];
exports.modules = {

/***/ 4505:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _modals_FuelingSuccess__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3062);
/* harmony import */ var _modals_OrbitingP2E__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3710);
/* harmony import */ var _modals_StellarInnovation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8416);
/* harmony import */ var _modals_ExpandingHorizons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2857);
/* harmony import */ var _modals_GalacticContribution__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6934);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_modals_GalacticContribution__WEBPACK_IMPORTED_MODULE_6__]);
_modals_GalacticContribution__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */ 






function InterStellarParentModal({ inerStellarModalOpen , setInerStellarModalOpen  }) {
    const [fuelingSuccessHover, setFuelingSuccessHover] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [orbitingP2EHover, setOrbitingP2EHover] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [stellarInnovationHover, setStellarInnovationHover] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [expandingHorizonsHover, setExpandingHorizonsHover] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [galacticContributionsHover, setGalacticContributionsHover] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [fuelingSuccessModalOpen, setFuelingSuccessModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [orbitingP2EModalOpen, setOrbitingP2EModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [stellarInnovationModalOpen, setStellarInnovationModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [expandingHorizonsModalOpen, setExpandingHorizonsModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [galacticContributionsModalOpen, setGalacticContributionsModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: inerStellarModalOpen && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "bg-[#010417] fixed inset-0 h-full w-full z-20 p-16",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "fixed inset-0 flex items-center justify-center z-30",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-[#424242] fixed top-10 left-10 z-30",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                onClick: ()=>[
                                        setInerStellarModalOpen(false)
                                    ],
                                className: "cursor-pointer hover:cursor-pointer",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iconify-icon", {
                                    height: "35",
                                    width: "35",
                                    icon: "radix-icons:cross-1"
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "text-5xl font-extrabold text-[#424242] text-center uppercase space-y-16 mt-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    onClick: ()=>setFuelingSuccessModalOpen(true),
                                    onMouseEnter: ()=>{
                                        setFuelingSuccessHover(true);
                                    },
                                    onMouseLeave: ()=>{
                                        setFuelingSuccessHover(false);
                                    },
                                    className: "hover:text-white transition-all cursor-pointer font-berlin",
                                    children: "Fueling Success"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    onClick: ()=>setOrbitingP2EModalOpen(true),
                                    onMouseEnter: ()=>{
                                        setOrbitingP2EHover(true);
                                    },
                                    onMouseLeave: ()=>{
                                        setOrbitingP2EHover(false);
                                    },
                                    className: "hover:text-white transition-all cursor-pointer font-berlin",
                                    children: "Orbiting P2E"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    onClick: ()=>setStellarInnovationModalOpen(true),
                                    onMouseEnter: ()=>{
                                        setStellarInnovationHover(true);
                                    },
                                    onMouseLeave: ()=>{
                                        setStellarInnovationHover(false);
                                    },
                                    className: "hover:text-white transition-all cursor-pointer font-berlin",
                                    children: "Stellar Innovation"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    onClick: ()=>setExpandingHorizonsModalOpen(true),
                                    onMouseEnter: ()=>{
                                        setExpandingHorizonsHover(true);
                                    },
                                    onMouseLeave: ()=>{
                                        setExpandingHorizonsHover(false);
                                    },
                                    className: "hover:text-white transition-all cursor-pointer font-berlin",
                                    children: "Expanding Horizons"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    onClick: ()=>setGalacticContributionsModalOpen(true),
                                    onMouseEnter: ()=>{
                                        setGalacticContributionsHover(true);
                                    },
                                    onMouseLeave: ()=>{
                                        setGalacticContributionsHover(false);
                                    },
                                    className: "hover:text-white transition-all cursor-pointer font-berlin",
                                    children: "Galactic Contributions"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/images/fuelingSuccess.svg",
                    className: `fixed bottom-0 right-0 ${fuelingSuccessHover ? "opacity-100" : "opacity-0"} transition-all duration-700}`,
                    alt: ""
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/images/orbitingP2e.svg",
                    className: `fixed -top-20 right-0 ${orbitingP2EHover ? "opacity-100" : "opacity-0"} transition-all duration-700}`,
                    alt: ""
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/images/stellarInnovation.svg",
                    className: `fixed bottom-0 right-0 ${stellarInnovationHover ? "opacity-100" : "opacity-0"} transition-all duration-700}`,
                    alt: ""
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/images/expandingHorizons.svg",
                    className: `fixed bottom-0 right-1/2 translate-x-1/2 ${expandingHorizonsHover ? "opacity-100" : "opacity-0"} transition-all duration-700}`,
                    alt: ""
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/images/galacticContributions.svg",
                    className: `fixed bottom-0 right-0 ${galacticContributionsHover ? "opacity-100" : "opacity-0"} transition-all duration-700}`,
                    alt: ""
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modals_FuelingSuccess__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    fuelingSuccessModalOpen: fuelingSuccessModalOpen,
                    setFuelingSuccessModalOpen: setFuelingSuccessModalOpen
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modals_OrbitingP2E__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    orbitingP2EModalOpen: orbitingP2EModalOpen,
                    setOrbitingP2EModalOpen: setOrbitingP2EModalOpen
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modals_StellarInnovation__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    stellarInnovationModalOpen: stellarInnovationModalOpen,
                    setStellarInnovationModalOpen: setStellarInnovationModalOpen
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modals_ExpandingHorizons__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    expandingHorizonsModalOpen: expandingHorizonsModalOpen,
                    setExpandingHorizonsModalOpen: setExpandingHorizonsModalOpen
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modals_GalacticContribution__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    galacticContributionsModalOpen: galacticContributionsModalOpen,
                    setGalacticContributionsModalOpen: setGalacticContributionsModalOpen
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InterStellarParentModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* eslint-disable @next/next/no-img-element */ 

function FuelingSuccess({ expandingHorizonsModalOpen , setExpandingHorizonsModalOpen , standAlone =false  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: expandingHorizonsModalOpen && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "bg-[#010417] fixed inset-0 h-full w-full z-30 p-16 overflow-auto",
            children: [
                standAlone == false && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        onClick: ()=>setExpandingHorizonsModalOpen(false),
                        src: "/images/hamburger.png",
                        className: "h-5 cursor-pointer",
                        alt: ""
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-16 w-[65%]",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "uppercase text-5xl text-white font-extrabold",
                            children: "Expanding Horizons"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-10 text-white space-y-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "mt-1 leading-7 font-poppins",
                                    children: [
                                        "Sharing value ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " By marketing and developing of our 'Ultimate Destination' project, the universe ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " ",
                                        "will be enlightened with our plans, all eyes will be on FROGGIES Token. ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " Valued on all planets ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " We will continue collaborations with third parties to turn FROGGIES Token into a ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " means of real-life payments. Envision online stores where you can check-out ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " using your Froggies Token!",
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " Full Booster Launch ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " The future release of our entertainment platform will be entirely powered by ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " ",
                                        "$FRGST. A whole FROGGIEVERSE of play to earn gaming systems."
                                    ]
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/images/expandingHorizons.svg",
                    className: `fixed bottom-0 right-1/2 translate-x-1/2  transition-all duration-700}`,
                    alt: ""
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FuelingSuccess);


/***/ }),

/***/ 3062:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* eslint-disable @next/next/no-img-element */ 

function FuelingSuccess({ fuelingSuccessModalOpen , setFuelingSuccessModalOpen , standAlone =false  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: fuelingSuccessModalOpen && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "bg-[#010417] fixed inset-0 h-full w-full z-30 p-16 overflow-auto",
            children: [
                standAlone == false && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        onClick: ()=>setFuelingSuccessModalOpen(false),
                        src: "/images/hamburger.png",
                        className: "h-5 cursor-pointer",
                        alt: ""
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-16 w-[65%]",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "uppercase text-5xl text-white font-extrabold",
                            children: "fueling success"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mt-10 text-white space-y-8",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center font-poppins text-white space-x-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "underline",
                                                    children: "Migration to an upgraded BSC contract"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "bg-[#27A167] px-4 rounded-full hidden",
                                                    children: "Done"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "mt-1 leading-7",
                                            children: "We migrated to BSC to ensure a more stable liquidity pool and provide holders and investors with lower gas fees. Building utility on BSC means building on security and affordable transactions."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center font-poppins text-white space-x-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "underline",
                                                    children: "Release fully functional P2E"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "bg-[#27A167] px-4 rounded-full hidden",
                                                    children: "Done"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "mt-1 leading-7",
                                            children: "We have been working on our P2E for many months, and we are close to delivering. 'Fully functional' means our P2E (https://www.everlost.io) is working on both PC and Mobile Phone and is supported by Wallet Connect."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center font-poppins text-white space-x-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "underline",
                                                    children: "Launching an upgraded website"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "bg-[#27A167] px-4 rounded-full hidden",
                                                    children: "Done"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "mt-1 leading-7",
                                            children: "The website you are reading right now is FROGGIES new and upgraded website. Lots of time and creativity went into the creation of this beautiful collaboration of outer space art."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center font-poppins text-white space-x-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "underline",
                                                    children: "Start development of staking contract"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "bg-[#DEAB28] px-4 rounded-full hidden",
                                                    children: "Building"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "mt-1 leading-7",
                                            children: "We are starting the development of a safe, and well rewarding staking platform. Generative APY's, and safety one can rely on. Release the satellites FROGGIES is scaling up its ambassador program, increasing marketing capabilities and investments while finding meaningful collaborations to achieve broader market exposure."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center font-poppins text-white space-x-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "underline",
                                                    children: "Release the satellites"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "bg-[#6978FF] px-4 rounded-full",
                                                    children: "Upcoming"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "mt-1 leading-7",
                                            children: "FROGGIES is scaling up its ambassador program, increasing marketing capabilities and investments while finding meaningful collaborations to achieve broader market exposure."
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/images/fuelingSuccess.svg",
                    className: `fixed bottom-0 right-0  transition-all duration-700}`,
                    alt: ""
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FuelingSuccess);


/***/ }),

/***/ 6934:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _helper_graph__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(100);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */ 



function FuelingSuccess({ galacticContributionsModalOpen , setGalacticContributionsModalOpen , standAlone =false  }) {
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: galacticContributionsModalOpen && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "bg-[#010417] fixed inset-0 h-full w-full z-30 p-16 overflow-auto",
            children: [
                standAlone == false && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        onClick: ()=>setGalacticContributionsModalOpen(false),
                        src: "/images/hamburger.png",
                        className: "h-5 cursor-pointer",
                        alt: ""
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-16 w-[65%]",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "uppercase text-5xl text-white font-extrabold",
                            children: "Galactic contributions"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            //action="https://script.google.com/macros/s/AKfycbx9nyGmD_gCLB3n8BeKktnYZuFEDC7qxNy2ABOP1ATCkPgig3FbtPTjIgeUMXu2Y5kbLw/exec"
                            //method="post"
                            onSubmit: async (e)=>{
                                // send a post request to the appScript url
                                e.preventDefault();
                                if (message.length < 1) {
                                    alert("Please enter a message");
                                    return;
                                }
                                const mutation = _helper_graph__WEBPACK_IMPORTED_MODULE_3__/* .gql */ .P`
                  mutation MyMutation {
                    createResponse(data: { message: "${message}" }) {
                      id
                    }
                  }
                `;
                                const res = await _helper_graph__WEBPACK_IMPORTED_MODULE_3__/* .graphBase.request */ .i.request(mutation);
                                if (res.createResponse.id) {
                                    alert("Your message has been sent");
                                    setMessage("");
                                } else {
                                    alert("There was an error sending your message");
                                }
                            },
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "mt-5 text-white",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "mt-1 leading-7 font-poppins",
                                                children: "Submit your ideas and become a contributor in the galaxy."
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                            name: "Responses",
                                            id: "",
                                            value: message,
                                            onChange: (e)=>setMessage(e.target.value),
                                            rows: 7,
                                            className: "w-[600px] text-black leading-7 bg-[#B1B3C4] font-poppins p-7 placeholder:text-black rounded-md mt-10",
                                            placeholder: "Add a description"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "submit",
                                    className: "uppercase font-medium text-sm text-black bg-[#B1B3C4] w-32 h-12 text-center cursor-pointer rounded-md mt-5",
                                    children: "Send"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/images/galacticContribution.svg",
                    className: `fixed top-0 right-0  transition-all duration-700}`,
                    alt: ""
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FuelingSuccess);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3710:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* eslint-disable @next/next/no-img-element */ 

function FuelingSuccess({ orbitingP2EModalOpen , setOrbitingP2EModalOpen , standAlone =false  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: orbitingP2EModalOpen && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "bg-[#010417] fixed inset-0 h-full w-full z-30 p-16 overflow-auto",
            children: [
                standAlone == false && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        onClick: ()=>setOrbitingP2EModalOpen(false),
                        src: "/images/hamburger.png",
                        className: "h-5 cursor-pointer",
                        alt: ""
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-16 w-[65%]",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "uppercase text-5xl text-white font-extrabold",
                            children: "orbiting p2e"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-10 text-white space-y-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "mt-1 leading-7",
                                    children: [
                                        "Continuous development of our P2E ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " More functionalities, visuals, levels, and gameplay will be added to Everlost.",
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        "Staking platform release ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " The time has arrived to reward those that believe in us. Stake your FROGGIES ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " Token and gain more rewards with time. ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " Space Entertainment ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " We are planning and development of our entertainment platform. This platform",
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " will allow our holders to use their Froggies Token for means of entertainment and ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " more game play. ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " Share our wealth from Galaxy ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " We are aiming for a listing on a top 50 Centralized Exchange to allow more ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " ",
                                        "$FRGST to be traded and increase our overall volume and exposure."
                                    ]
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/images/orbitingP2e.svg",
                    className: `fixed bottom-0 right-0  transition-all duration-700}`,
                    alt: ""
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FuelingSuccess);


/***/ }),

/***/ 8416:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* eslint-disable @next/next/no-img-element */ 

function FuelingSuccess({ stellarInnovationModalOpen , setStellarInnovationModalOpen , standAlone =false  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: stellarInnovationModalOpen && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "bg-[#010417] fixed inset-0 h-full w-full z-30 p-16 overflow-auto",
            children: [
                standAlone == false && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        onClick: ()=>setStellarInnovationModalOpen(false),
                        src: "/images/hamburger.png",
                        className: "h-5 cursor-pointer",
                        alt: ""
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-16 w-[65%]",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "uppercase text-5xl text-white font-extrabold",
                            children: "Stellar innovation"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-10 text-white space-y-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "mt-1 leading-7",
                                    children: [
                                        "Stellar amusement ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " As we release our first part of the entertainment platform we will provide our ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " holders with more usability for their Froggies Token ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " NFT with galactic use-case ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " Imagine an NFT that does not only have the value of art, but also contains an ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " actual use-case. Think of rewards, staking NFTs, lotteries and more. ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " Ultimate destination ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " Prepare for the Ultimate Destination by starting the development of something ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " ",
                                        "unique (we cannot disclose, others are watching). This will put Froggies Token on ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " the map for becoming one of the top Memecoins on the market."
                                    ]
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/images/stellarInnovation.svg",
                    className: `fixed bottom-0 right-0  transition-all duration-700}`,
                    alt: ""
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FuelingSuccess);


/***/ }),

/***/ 100:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* reexport safe */ graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql),
/* harmony export */   "i": () => (/* binding */ graphBase)
/* harmony export */ });
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);

const graphBase = new graphql_request__WEBPACK_IMPORTED_MODULE_0__.GraphQLClient("https://api-ap-south-1.hygraph.com/v2/cldx4j2k500ir01ugevu6f4un/master", {
    headers: {
        Authorization: "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImdjbXMtbWFpbi1wcm9kdWN0aW9uIn0.eyJ2ZXJzaW9uIjozLCJpYXQiOjE2NzU5NDg3OTQsImF1ZCI6WyJodHRwczovL2FwaS1hcC1zb3V0aC0xLmh5Z3JhcGguY29tL3YyL2NsZHg0ajJrNTAwaXIwMXVnZXZ1NmY0dW4vbWFzdGVyIiwibWFuYWdlbWVudC1uZXh0LmdyYXBoY21zLmNvbSJdLCJpc3MiOiJodHRwczovL21hbmFnZW1lbnQuZ3JhcGhjbXMuY29tLyIsInN1YiI6ImMwYmZjNmJkLWEwNzctNDg4Ny1hNjAwLWJlMTdiNjc2ZjcxNyIsImp0aSI6ImNsZHg0bjF4cTAxbjMwMXVmOHdqdmZuNXIifQ.ehXc5WuaIlAvUOlVIaseecY_cU8rORA5hpMQsPnpPzL4OC_5l2MptPfNB7PK9-J9gEyEf4wjSiT_wNSwpG8CYG71NTn939O_gW9B3xyDF_IzAFOh15SLY_Bt_lDwIZdMl-1RxoAZ-NOGxUBzEG92ZhTaintAUnTjFmH1w75VQ--nQJeZxqmT3iRietsDN94CdhodY-2D-b9opwpVoa-SbpHpA3hxifRFqDYu6Pd68NZA8i0pOOFz6y322siMkx1fLsseEIJkDxXsLdcYhkAiMe3wdbSNHOu97-V8hipyZY-6pYOmpf0aM7eXb9qB_U4mhCu0Z1VjJxleidz7RZQmdgWu7nQEFdvDxIwZH0YazAGThGesMao_UdomAc-ggtoOEAP70OULJcJLkG8qtR2mITpv9OLKc-W0ard1J986oaU0ObeEgNeNFD9UneZI0vxZaREYSAroDswN4AsP4tVvbGVWaaDaAxVOQCSxfQzOdRWZP1RL3UlLy4qiNnWBCEDcp7dIXfeM0nokOa-eCZ2RNFQGwH-kzq3OY7kXqQdZxsGg17m2Z_GoDGKM76i3B3msqyXErh-BPlEtpNgfaU3ANMQbpAo3buQqeLkZohq3eO-8-iQpyLvVIu1aG-HqcmEllz0Z5bSEu5Gp0fAB2OPbApUmp4D-KeFmIAKFE4lAMbg"
    }
});



/***/ })

};
;